
<div class="row">
        <div class="col-md-12">
            <?php
            $success=$this->session->userdata('success');
            if ($success != "") {   
            ?>
            <div class="alert alert-success"><?php  echo $success;?></div>
            <?php
             }
            ?>
            <?php
            $failure=$this->session->userdata('failure');
            if ($failure != "") {   
            ?>
            <div class="alert alert-success"><?php echo $failure; ?></div>
            <?php
             }
            ?>
        </div>
    </div> 



<div id="content">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="row mb-xl-4 mb-0">
                            <div class="col-12 col-sm-6 col-xl-3 mb-4 mb-xl-0">
                                <div class="card redial-border-light redial-shadow">
                                    <div class="card-body">
                                        <div class="media d-block d-sm-flex text-center text-sm-left">
                                            <div class="media-body">
                                                <div class="fact-box1 text-center text-sm-center">
                                                    <h2 class="mb-1 text-primary"><i class="fa fa-credit-card"></i></h2>
                                                    <h6 class="mb-6 ">5</h6>
                                                    <p class="mb-2">Projects</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-xl-3 mb-4 mb-xl-0">
                                <div class="card redial-border-light redial-shadow">
                                    <div class="card-body">
                                        <div class="media d-block d-sm-flex text-center text-sm-left">
                                            <div class="media-body">
                                                <div class="fact-box2 text-center text-sm-center">
                                                    <h2 class="mb-1 text-primary"><i class="fa fa-sitemap"></i></h2>
                                                    <h6 class="mb-6">73</h6>
                                                    <p class="mb-2">Tasks</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-xl-3 mb-4 mb-xl-0">
                                <div class="card redial-border-light redial-shadow">
                                    <div class="card-body">
                                        <div class="media d-block d-sm-flex text-center text-sm-left">
                                            <div class="media-body">
                                                <div class="fact-box1 text-center text-sm-center">
                                                    <h2 class="mb-1 text-primary"><i class="icofont icofont-ui-user pr-1"></i></h2>
                                                    <h6 class="mb-6">3</h6>
                                                    <p class="mb-2">Clients</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 col-xl-3">
                                <div class="card redial-border-light redial-shadow">
                                    <div class="card-body">
                                        <div class="media d-block d-sm-flex text-center text-sm-left">
                                            <div class="media-body">
                                                <div class="fact-box1 text-center text-sm-center">
                                                    <h2 class="mb-1 text-primary"><i class="fa fa-user-circle"></i></h2>
                                                    <h6 class="mb-6">5</h6>
                                                    <p class="mb-2">Leads</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>


                        //

                        <!-- main-content-->
          <body class="loginback bg-overlay">

        <!-- main-content-->
        <div class="wrapper" >
            <div class="w-100">
                <div class="row d-flex justify-content-center  pt-4 pb-4 mt-5">
                    <div class="col-12 col-xl-4">
                        <div class="card" style="border-radius: 4px;">
<!--                           <div class="card-body text-center">
                                
                            </div>-->
                            <h4 class="mb-0 redial-font-weight-400 ribbon">Please Sign Up</h4>
                            <div class="redial-divider"></div>
                            <div class="card-body py-4 text-center registercard">
                                <h4>LSSPMS</h4>
<!--                                <img src="dist/images/logo-v2.png" alt="" class="img-fluid mb-4">-->
                                <form action="<?php  echo base_url();?>admin/signup_management/create" method="post">
                                        <div class="form-group">
                                        <input type="text" class="form-control" placeholder="User Name" name="name" required="Please enter uname">
                                        </div>  
                                         
                                        <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Email Id" name="email"  required="Please enter emailid">
                                        </div> 
                                        <div class="form-group">
                                        <input type="password" class="form-control" placeholder="password" name="password" required="Please enter password">
                                        </div>
                                        <div class="form-group">
                                        <input type="number" class="form-control" placeholder="mobilenumber"  value="   mobilenumber" required="Please enter number">
                                        </div>
                                    
                                    
                                <button class="btn btn-primary" type="submit">Submit</button>       </form>
                            </div>
                            <div class="card-footer text-center">
                                <p class="mb-0">Already have account ? <a href="<?php  echo base_url().'admin/signin';?>"> Sign in</a></p>
                            </div>
                        </div>
                    </div>
                </div>   
            </div>
        </div>
        <!-- End main-content-->