


<div class="row">
        <div class="col-md-12">
            <?php
            $success=$this->session->userdata('success');
            if ($success != "") {   
            ?>
            <div class="alert alert-success"><?php  echo $success;?></div>
            <?php
             }
            ?>
            <?php
            $failure=$this->session->userdata('failure');
            if ($failure != "") {   
            ?>
            <div class="alert alert-success"><?php echo $failure; ?></div>
            <?php
             }
            ?>
        </div>
    </div> 


<section class="content">
  <div class="container">
      <div class="row">
      <!-- right column -->
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Add New Product</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                
                <form name="form" id="form" method="post" action="<?php  echo base_url()?>product/product_management/create"
                 enctype="multipart/form-data">
                  <div class="col-md-6">
                    <div class="form-group">
                      <input type="hidden" name="id">
                      <label for="code">Product Code<span class="validation-color">*</span></label>
                      <input type="text" class="form-control" id="code" name="Item_code" value="">
                      <span class="validation-color" id="err_code"></span>
                    </div>

                    <div class="form-group">
                      <label for="name">Product name <span class="validation-color">*</span></label>
                      <input type="text" class="form-control" id="name" name="Item_name" value="">
                      <span class="validation-color" id="err_name"></span>
                    </div>
                      <div class="form-group">
                      <label for="category">Select Category <span class="validation-color">*</span></label>
                      <select class="form-control select2" id="category" name="fabric_category"  style="width: 100%;">
                        <option>--Select--</option>
                        <option value="hello">add1</option>
                        <option value="hello">add2</option>
                        <option value="hello">add3</option>



        </select>
                      <span class="validation-color" id="err_category"></span>
                    </div>

                    <div class="form-group">
                      <label for="subcategory">Select Subcategory <span class="validation-color">*</span></label>
                      <select class="form-control select2" id="subcategory" name="fabric _subcategory" style="width: 100%;">
                       <option>--Select--</option>
                        <option value="hii">add11</option>
                        <option value="hii">add22</option>
                        <option value="hii">add33</option>
                        
                      </select>
                      <span class="validation-color" id="err_subcategory"></span>
                    </div>


                      <div class="form-group">
                      <label for="unit">Product printtype <span class="validation-color">*</span></label>
                      <input type="text" class="form-control" id="unit" name="select_print_type" value="">
                      <span class="validation-color" id="err_unit"></span>
                    </div>

                     <div class="form-group">
                      <label for="size">Product select color </label>
                      <input type="text" class="form-control" id="size" name="select_color" value="">
                      <span class="validation-color" id="err_size"></span>
                    </div>
                      <div class="form-group">
                      <label for="hsn_sac_code">Construction</label>
                      <input type="text" class="form-control" id="hsn_sac_code" name="construction" value="">
                      <a href="" data-toggle="modal" data-target="#myModal"></span></a>
                      <span class="validation-color" id="err_hsn_sac_code"></span>
                    </div>
                     <div class="form-group">
                      <label for="weave">Product weave </label>
                      <textarea class="form-control" id="weave" name="weave" value=""></textarea>
                      <span class="validation-color" id="weave"></span>
                    </div>
                  </div>
                  <div class="col-md-6">

                    <div class="form-group">
                      <label for="cost">Product price <span class="validation-color">*</span></label>
                      <input type="text" class="form-control" id="cost" name="price" value="">
                      <span class="validation-color" id="err_cost"></span>
                    </div>
                    <div class="form-group">
                      <label for="price">Product Quantity <span class="validation-color">*</span></label>
                      <input type="text" class="form-control" id="price" name="quantity" value="">
                      <span class="validation-color" id="err_price"></span>
                    </div>

                    <div class="form-group">
                      <label for="alert_quantity">About item Quantity </label>
                      <input type="text" class="form-control" id="alert_quantity" name="about_the_item" value="">
                      <span class="validation-color" id="err_alert_quantity"></span>
                    </div>

                    <div class="form-group">
                      <label for="thread_count">Product thread_count </label>
                      <textarea class="form-control" id="thread_count" name="thread_count"></textarea>
                      <span class="validation-color" id="err_note"></span>
                    </div>
                     

                    <div class="form-group">
                      <label for="tax"> Product gram </label>
                      <input type="text"  id="tax" name="gram" style="width: 100%;">

                      <span class="validation-color" id="err_tax"></span>
                    </div>
                     <div class="form-group">
                      <label for="subcategory">
                      Product fabric type
                      <!-- Select Subcategory --> <span class="validation-color"></span></label>
                      <input type="text"  id="brand" name="fabric_type" style="width: 100%;">
                      
                    </div>
               
                  </div>
                  </div>
                   <div class="form-group">
                      <label for="image">Product Image </label>
                      <input type="file"  id="add_Images" name="add_Images" >
                      <span class="validation-color" id="add_Images"></span>
                      
                    </div>
                  </div>
                <div class="col-sm-12">
                  <div class="box-footer">
                    <button type="submit" id="submit" class="btn btn-info">ADD</button>
                    <span class="btn btn-default" id="cancel" style="margin-left: 2%" onclick="cancel('product')"><a href="<?php  echo base_url().'product/productlist';?>">
                    Cancel</a></span>
                  </div>
                </div>
                </form>
          </div>
          <!-- /.box-body -->
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
</div>
</div>
  
  <!-- /.content-wrapper -->
