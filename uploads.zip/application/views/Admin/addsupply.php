
<?php 
//print_r($updaterecord);
error_reporting(0);
if($updaterecord){
$action = 'update';
}else{
 $action = 'create';   
}
 ?>

<div class="row">
        <div class="col-md-12">
            <?php
            $success=$this->session->userdata('success');
            if ($success != "") {   
            ?>
            <div class="alert alert-success"><?php  echo $success;?></div>
            <?php
             }
            ?>
            <?php
            $failure=$this->session->userdata('failure');
            if ($failure != "") {   
            ?>
            <div class="alert alert-success"><?php echo $failure; ?></div>
            <?php
             }
            ?>
        </div>
    </div> 

    <div class="container">
<section class="content">
      <div class="row">
      <!-- right column -->
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Add New Product</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                
                <form name="frm" id="form" method="post" action="<?php  echo base_url()?>product/product_management/<?php echo $action;?>"
                 enctype="multipart/form-data">
                  <div class="col-md-6">
                    <div class="form-group">
                      <input type="hidden" name="id" value="<?php  echo $updaterecord['id']; ?>">
                      <label for="code">Product Code<span class="validation-color">*</span></label>
                      <input type="text" class="form-control" id="code" name="code" value="<?php echo $updaterecord['code']; ?>">
                      <span class="validation-color" id="err_code"></span>
                    </div>

                    <div class="form-group">
                      <label for="name">Product Name <span class="validation-color">*</span></label>
                      <input type="text" class="form-control" id="name" name="name" value="<?php  echo $updaterecord['name'];?>">
                      <span class="validation-color" id="err_name"></span>
                    </div>

                    <div class="form-group">
                      <label for="hsn_sac_code">HSN/SAC Code</label>
                      <input type="text" class="form-control" id="hsn_sac_code" name="hsn_sac_code" value="<?php echo $updaterecord['hsn_sac_code'];?>">
                      <a href="" data-toggle="modal" data-target="#myModal">HSN/SAC Lookup</span></a>
                      <span class="validation-color" id="err_hsn_sac_code"></span>
                    </div>

                    <div class="form-group">
                      <label for="category">Select Category <span class="validation-color">*</span></label>
                      <select class="form-control select2" id="category" name="category" onchange="test(this.value);" style="width: 100%;">
                        <option>--Select--</option>

                        <?php foreach ($record as $key=>$value){

                        ?>

                        <option <?php if(!empty($updaterecord)){if($updaterecord['category']==$value['id']){echo "selected";}} ?> value='<?php  echo $value['id'];?>'>
                          <?php  echo $value['category_name'];?></option>

                        <?php }?>                                               </select>
                      <span class="validation-color" id="err_category"></span>
                    </div>

                    <div class="form-group">
                      <label for="subcategory">Select Subcategory <span class="validation-color">*</span></label>
                      <select class="form-control select2" id="subcategory" name="subcategory" style="width: 100%;">

                        <option>Select</option>
                        <?php  foreach($record3 as $key => $value){
                        ?>
                      
                        <option value="<?php echo $value['id'];?>" selected="<?php if($value['id']==$updaterecord['id']){echo "selected";}?>">    
                        
                        <?php  echo $value['subcategory_name'];?></option>

                    <?php }?> 
                      </select>
                      <span class="validation-color" id="err_subcategory"></span>
                    </div>
                    <div class="form-group">
                      <label for="subcategory">
                      Select Brand
                      <!-- Select Subcategory --> <span class="validation-color"></span></label>
                      <select class="form-control select2" id="brand" name="brand" style="width: 100%;">
                        <option>---Select--</option>
                        <?php  foreach ($record1 as $key => $value){

                        ?>
                  <option  <?php if(!empty($updaterecord)){if($updaterecord['brand']==$value['id']){echo "selected";}} ?> value='<?php  echo $value['id'];?>'>
                        <?php  echo $value['brand_name'];?> </option>                          
                      <?php }?>
                        </select>
                        
                 
                      
                    </div>
                    <div class="form-group">
                      <label for="unit">Product Unit <span class="validation-color">*</span></label>
                      <input type="text" class="form-control" id="unit" name="unit" value="<?php  echo $updaterecord['unit'];?>">
                      <span class="validation-color" id="err_unit"></span>
                    </div>

                    <div class="form-group">
                      <label for="size">Product Size </label>
                      <input type="text" class="form-control" id="size" name="size" value="<?php  echo $updaterecord['size'];?>">
                      <span class="validation-color" id="err_size"></span>
                    </div>

                  </div>
                  <div class="col-md-6">

                    <div class="form-group">
                      <label for="cost">Product Cost <span class="validation-color">*</span></label>
                      <input type="text" class="form-control" id="cost" name="cost" value="<?php  echo $updaterecord['cost'];?>">
                      <span class="validation-color" id="err_cost"></span>
                    </div>
                    <div class="form-group">
                      <label for="price">Net Dealer Price <span class="validation-color">*</span></label>
                      <input type="text" class="form-control" id="price" name="price" value="<?php  echo $updaterecord['price'];?>">
                      <span class="validation-color" id="err_price"></span>
                    </div>

                    <div class="form-group">
                      <label for="alert_quantity">Alert Quantity </label>
                      <input type="text" class="form-control" id="alert_quantity" name="alert_quantity" value="<?php  echo $updaterecord['alert_quantity'];?>">
                      <span class="validation-color" id="err_alert_quantity"></span>
                    </div>

                    <div class="form-group">
                      <label for="tax">Select Product Tax </label>
                      <select class="form-control select2" id="tax" name="tax" style="width: 100%;">
                        <option>Select</option>

                        <?php  foreach($record2 as $key=>$value){
                        ?>

                        <option <?php if(!empty($updaterecord)){if($updaterecord['tax']==$value['id']){echo "selected";}} ?> value='<?php  echo $value['id'];?>'>
                          <?php  echo $value['tax_name'];?></option> 
                      <?php }?>

                      </select>
                      <span class="validation-color" id="err_tax"></span>
                    </div>

                    <div class="form-group">
                      <label for="image">Product Image </label>
                      <input type="file" class="" id="image" name="uploadfile"  value="">
                      <span class="validation-color" id="err_image"><?php  echo $updaterecord['uploadfile'];?></span>
                      <img src="<?php echo base_url();?>uploads/<?php  echo $updaterecord['uploadfile'];?>" alt="photo" style="border-radius: 50%; width:50px; height: 50px;">
                    </div>

                    <div class="form-group">
                      <label for="note">Product Detail for Invoice </label>
                      <textarea class="form-control" id="note" name="note" value=""><?php  echo $updaterecord['note'];?></textarea>
                      <span class="validation-color" id="err_note"></span>
                    </div>
                  </div>
                  </div>
                <div class="col-sm-12">
                  <div class="box-footer">
                    <button type="submit" id="submit" class="btn btn-info">ADD</button>
                    <span class="btn btn-default" id="cancel" style="margin-left: 2%" onclick="cancel('product')"><a href="<?php  echo base_url().'product/productlist';?>">
                    Cancel</a></span>
                  </div>
                </div>
                </form>
          </div>
          <!-- /.box-body -->
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  </div>
  <!-- /.content-wrapper -->
