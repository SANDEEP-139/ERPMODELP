  <div class="container">
 <section class="content">
      <div class="row">
      <!-- right column -->
      <div class="col-md-12">
        <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">List Product</h3>
              <a class="btn btn-sm btn-info pull-right" style="margin: 10px" href=<?php  echo base_url().'product/updateproductlist';?>>Add New Product</a>


            </div>
             <div class="something">
                    <label>Search <input name="search_data" id="search_data" type="text" onkeyup="ajaxSearch();"></label>
                    <div id="suggestions">
                        <div id="autoSuggestionsList">
                        </div>
                    </div>
                </div>
         
            <!-- /.box-header -->

            <div class="box-body">
              <table id="index" class="table table-bordered table-striped">
                <thead>
                  <tr>

                    <th>No</th>
                    <th>Image</th>
                    <th>Code</th>
                    <th>HSN/SAC Code</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Subcategory</th>
                    <th>Cost</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>tax</th>
                    <th>note</th>
                    <th>brand</th>
                    <th>Unit</th>
                    <th>Alert Quantity</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                


                 <?php    foreach($record as $user){?>

    <tr>
                     <td><?php  echo  $user['id']?></td>
                     <td><?php  echo  $user['search_data']?></td>
                     <td><?php echo $user['uploadfile']?></td>
                      <td><?php  echo  $user['code']?></td>
                      <td><?php  echo  $user['name']?></td>
                      <td><?php  echo  $user['hsn_sac_code']?></td>
                      <td><?php  echo  $user['category']?></td>
                      <td><?php  echo  $user['subcategory']?></td>
                      <td><?php  echo  $user['brand']?></td>
                      <td><?php  echo  $user['unit']?></td>
                      <td><?php  echo  $user['size']?></td>
                      <td><?php  echo  $user['cost']?></td>
                      <td><?php  echo  $user['price']?></td>
                      <td><?php  echo  $user['alert_quantity']?></td>
                       <td><?php  echo  $user['tax']?></td>
                       <td><?php  echo  $user['note']?></td>

                     
                
               <td>
                          
                          <a href="<?php  echo base_url().'product/updatelist/'.$user['id'];?>" title="Edit" class="btn btn-xs btn-info"><span class="glyphicon glyphicon-edit"></span></a>
                          <a href="<?php  echo base_url().'product/product_management/delete/'.$user['id'];?>" onclick="return confirm('Are you sure you want to delete this item?');" title="Delete" class="btn btn-xs btn-danger"> 
                        <span class="glyphicon glyphicon-trash"></span></a>

                      </td>
                      </tr><?php }?>

                                  <tfoot>

        <tr><td colspan="4">no record</td></tr>
          
                  <tr>
                    <th>No</th>
                    <th>Image</th>
                    <th>Code</th>
                    <th>HSN/SAC Code</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Subcategory</th>
                    <th>Cost</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Unit</th>
                    <th>tax</th>
                    <th>brand</th>
                    <th>note</th>
                    <th>Alert Quantity</th>
                    <th>Action</th>
                  </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  </div>

  