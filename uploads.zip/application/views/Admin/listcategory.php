<!DOCTYPE>
<!DOCTYPE html>
<html>
<head>
  <title>  CI CRUD Application View users</title>
  <link rel="stylesheet" type="text/css" href="<?php  echo base_url().'assetes/css/bootstrap.min.css';?>">
</head>
<body>

<div class="container" style="padding: 10px;">
  <div class="row">
    <div class="col-md-12">
      <?php
      $success=$this->session->userdata('success');
      if ($success != "") { 
      ?>
      <div class="alert alert-success"><?php  echo $success;?></div>
      <?php
         }
      ?>
      <?php
      $failure=$this->session->userdata('failure');
      if ($failure != "") { 
      ?>
      <div class="alert alert-success"><?php echo $failure; ?></div>
      <?php
         }
      ?>
    </div>
  </div>
<div class="row">
  <div class="col-md-8">
    <div class="row">
  <div class="col-6"><h3>List Category</h3></div>
  <div class="col-6 text-right">
    <a href="<?php  echo base_url().'product/updatecategory';?>" class=" btn btn-primary">Create</a>
    </div>
     </div>
     <hr>
   </div>
</div>

  <div class="row">
    <div class="col-md-8">
      <table class="table table-striped">
        <tr>
          <th>ID</th>
          <th>Name</th>
          
          <th width="60">Edit</th>
          <th width="100">Delete</th>
        </tr>
        <?php  foreach($record as $user) { ?>
        <tr>
          <td><?php  echo  $user['id']?></td>
          <td><?php  echo  $user['category_name']?></td>
         
          <td>
            <a href="<?php echo base_url().'product/edit/'.$user['id']?>" class=" btn btn-primary">Edit</a>
          </td>
          <td>
            <a href="<?php echo base_url().'product/delete/'.$user['id']?>" class=" btn btn-danger">Delete</a>
          </td>
        </tr>
     
        <tr>
          <td colspan="5">Record not found</td>
        </tr>
      <?php }?>
      </table>
    </div>
    
  </div>
  
</div>
</body>
</html>