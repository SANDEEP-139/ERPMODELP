
<!DOCTYPE html>
<html>
<head>
  <title> Crud Application Create user</title>
  
</head>
<body>

<div class="container" style="padding: 10px;" >
  <h3> Add category</h3>
  <hr>
  <form   method ="post" action="<?php  echo base_url().'product/';?>">
  <div class="row">

    <div class="col-md-6">
      <div class ="form-group">
        <label> Category Name</label>
        <input type="text" name="name" value="" class="form-control">
        
      </div>
    <!--   <div class ="form-group">
        <label>Email</label>
        <input type="text" name="email" value="" class="form-control">
        
      </div> -->
      <div class ="form-group">
        <button class="btn btn-primary">Create</button>
        <a href="" class="btn btn-secondary btn">Cancel</a>
        
      </div>
      
    </div>
    
  </div>
  </form>
</div>
</body>
</html>