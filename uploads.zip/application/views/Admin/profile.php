
<?php 
//print_r($userrecord); die;
error_reporting(0);
if($userrecord){
$action = 'update';
}else{
 $action = 'create';   
}
 ?>


<div class="row">
        <div class="col-md-12">
            <?php
            $success=$this->session->userdata('success');
            if ($success != "") {   
            ?>
            <div class="alert alert-success"><?php  echo $success;?></div>
            <?php
             }
            ?>
            <?php
            $failure=$this->session->userdata('failure');
            if ($failure != "") {   
            ?>
            <div class="alert alert-success"><?php echo $failure; ?></div>
            <?php
             }
            ?>
        </div>
    </div> 

    

<section class="content">
      <!-- Small boxes (Stat box) -->
  

  
<!-- Page body start -->
<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <!-- Basic Form Inputs card start -->
            
                <div class="card-header">
                    <h5>Update Page </h5>
                </div>
                <div class="card-block">
                     <form  method="post" action="<?php  echo base_url().'admin/usermanagement/'.$action;?>">
                        <div class="form-group row">
                          <input type="hidden" name="hidden_id" value="<?php echo $userrecord['user_id']; ?>">
                            <label class="col-sm-2 col-form-label">Name</label>
                            <div class="col-sm-4">
                                <input type="text" name="name" value="<?php echo $userrecord['name'];?>" class="form-control">
                            </div>
                            <label class="col-sm-2 col-form-label">Email</label>
                            <div class="col-sm-4">
                                <input type="text" name="email" value="<?php echo $userrecord['email'];?>" class="form-control">
                            </div>
                        </div>
                         <div class="form-group row">
                            <label class="col-sm-2 col-form-label">Password.</label>
                            <div class="col-sm-4">
                                <input type="password" name="password" value="<?php echo $userrecord['password'];?>" class="form-control">
                            </div>
                            <label class="col-sm-2 col-form-label">Mobile number</label>
                            <div class="col-sm-4">
                              <input type="number" name=" mobilenumber" value="">  
                              
                            </div>
                        </div>
                         
                         
                           <label class="col-sm-2 col-form-label"></label>
                               <div class="col-sm-4">
                                   <input type="submit" name="submit" value="Update" class="btn btn-primary">
                                   <input type="reset" name="reset" value="Reset" class="btn btn-danger">
                                </div>           
                    </form>



                    
   
    
                    </div>
                     </div>


                </div>
            </div>
            <!-- Basic Form Inputs card end -->
       
  
       

        </section>
        <!-- /.Left col -->
        <!-- right col (We are only adding the ID to make the widgets sortable)-->
        <section class="col-lg-5 connectedSortable">

          <!-- Map box -->
          
          <!-- /.box -->

          <!-- solid sales graph -->
         
          <!-- /.box -->

          <!-- Calendar -->
         
          <!-- /.box -->

        </section>
      </div>
        <!-- right col -->
      </div>
      <!-- /.row (main row) -->

    
    <!-- /.content -->
  