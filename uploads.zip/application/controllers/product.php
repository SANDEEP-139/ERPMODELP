<?php
class Product extends CI_Controller 
{



public function __construct()
	{
	/*call CodeIgniter's default Constructor*/
	parent::__construct();
	
	
	}
	// #@par1 = id
	//$par1= read,update,delete
	//$par2=id	
//


//ajax// show data

    //ajax show data//
public function productlist(){
	
$pagedata['record'] = $this->db->get('add_product')->result_array();
	//print_r($pagedata); die; 
    $this->load->view('Admin/include/header');
    $this->load->view('Admin/listproduct',$pagedata);
    $this->load->view('Admin/include/footer');
   	//redirect('product/productlist');
}
	

	// product all list//
public function updateproductlist($par1=''){

	$pagedata['id']=$par1;
  //print_r($pagedata); die;
	if($par1){
$pagedata['updaterecord'] = $this->db->get_where('add_product',array('id'=>$par1))->row_array();

	}

	// category
	

   //print_r($pagedata); die;
	// $pagedata = 
    $this->load->view('Admin/include/header');
 $this->load->view('Admin/productadd',$pagedata);
 
 $this->load->view('Admin/include/footer');
   
   //	redirect('product/productlist');
}
	/* 
	$par1 = create, update, delete
	 
        $par2 = id
	*/

//product add//
        
        


 public function product_management($par1='',$par2='',$par3=''){ 

$config['upload_path'] = 'uploads/';
$config['allowed_types'] = 'gif|jpg|png|jpeg';
$this->load->library('upload', $config);
$this->upload->initialize($config);
@unlink('uploads');
 
if (!$this->upload->do_upload('add_Images')) {
$error = array('error' => $this->upload->display_errors());
 
//$this->load->view('productadd', $error);
}

else {
$data = array('productadd' => $this->upload->data());
 
$filename =  $this->upload->data('file_name');

}	

 $data=array(
    
		'Item_code'=>$this->input->post('Item_code'),
		'Item_name'=>$this->input->post('Item_name'),       
	     'fabric_category'=>$this->input->post('fabric_category'),
	    'fabric_subcategory'=>$this->input->post('fabric_subcategory'),
	     'fabric_type'=>$this->input->post('fabric_type'),
	     'select_print_type'=>$this->input->post('select_print_type'),
	     'select_color'=>$this->input->post('select_color'),
	     'price'=>$this->input->post('price'),
	     'quantity'=>$this->input->post('quantity'),
	     'about_the_item'=>$this->input->post('about_the_item'),
	     'thread_count'=>$this->input->post('thread_count'),
	     'construction'=>$this->input->post('construction'),
	     'gram'=>$this->input->post('gram'),
	     'fabric'=>$this->input->post('fabric'),
	     'weave'=>$this->input->post('weave'),
	     'add_Images'=>$this->input->post('add_Images')
         
	);
 
 
//print_r($data); die;
   $this->load->view('Admin/include/header');
    $this->load->view('admin/productadd');
    $this->load->view('Admin/include/footer');
 


 if($par1=='create'){
            

	 		
	 		
	 	$user=$this->db->insert('add_product' ,$data);
	 	if ($user) {
		# code...
	$this->session->set_flashdata('success','record added successfully');
    }
else{

      $this->session->set_flashdata('failure','record not added');
	
  }
  
redirect( base_url().'product/productlist');
	 		//
}
	 		


   if($par1=='update'){
	



	
	$id  =$this->input->post('id');
	$this->db->where( 'id' ,$id);
	$user=$this->db->update('add_product',$data);
	 ///echo $this->db->last_query();
 //  print_r($user); die;

	if ($user) {
		# code...
	$this->session->set_flashdata('success','record update successfully');
   }
else{

     $this->session->set_flashdata('failure','record not updated');
	
  }
  redirect('product/productlist');

}
	//update user recoord



 //redirect
//
	//delete
	 if ($par1=='delete') {
		 
		 
		
	 	$id=$par2;
	 	$this->db->where('id' ,$id);
	    $user=$this->db->delete('add_product');

	 	# code...
	  	 if($user){
	  	 	$this->session->set_flashdata('success','record deleted successfully');
	  	 	
	  	 }
	  	else
	  	{ 
	  	 $this->session->set_flashdata('failure','record not found in database');
	  
	  	}
	redirect(base_url().'product/productlist');
	  
	//
 }


//upload//

//upload//

 }  
   


//product list //


//tranferlist//

public function listjobworker()
{
$pagedata['record'] =$this->db->get('add_product')->result_array(); 


	//$pagerecord['record']=$this->db->get('tranfer')->result_array(); 
 // print_r($pagedata); die;
	$this->load->view('Admin/include/header');
    $this->load->view('admin/supplylist',$pagedata);
    $this->load->view('Admin/include/footer');
   
   	}


public function updatejobworker($par1=''){
$pagerecord['id']=$par1;
if($par1){
$pagerecord['updaterecord'] = $this->db->get_where('crud',array('id'=>$par1))->row_array();	
}


 $this->load->view('Admin/include/header');
    $this->load->view('admin/addsupply',$pagerecord);
    $this->load->view('Admin/include/footer');
}
//add tranfer//

 public function jobwoker_management($par1='',$par2='',$par3=''){
   

 $data=array(
    
	     'date'=>$this->input->post('date'),
	    'to_warehouse'=>$this->input->post('to_warehouse'),
	    'from_warehouse'=>$this->input->post('from_warehouse'),
	     'product'=>$this->input->post('product'),
         
          'note'=>$this->input->post('note')
	);

  $this->load->view('Admin/include/header');
    $this->load->view('admin/addsupply');
    $this->load->view('Admin/include/footer');


 if($par1=='create'){
            

	 		 $this->db->insert('crud' ,$data);
	 		
	 	}
	 		//echo $result;die;
	 		//if($result){
	 			//$this->session->set_flashdata('success','record added successfully');
	 		//}else{
	 			//$this->session->set_flashdata('fail','unable to add please check');
	 		//}
	 		
	 		//redirect('product/productlist');
 //redirect


   if($par1=='update'){
	
	
	$id  =$this->input->post('id');
	$this->db->where( 'id' ,$id);
	$result=$this->db->update('crud',$data);

	if ($result) {
		# code...
	$this->session->set_flashdata('success','record update successfully');
    }
else{

      $this->session->set_flashdata('failure','record not updated');
	
  }
  redirect('product/listjobworker');

}
	//update user recoord

 

 //redirect
//
	//delete
	 if ($par1=='delete') {
		 
		 
		
	 	$id=$par2;
	 	$this->db->where('id' ,$id);
	    $user=$this->db->delete('crud');

	 	# code...
	  	 if($user){
	  	 	$this->session->set_flashdata('success','record deleted successfully');
	  	 	
	  	 }
	  	else
	  	{ 
	  	 $this->session->set_flashdata('failure','record not found in database');
	  
	  	}
	redirect(base_url().'product/listjobworker');
	  
	//
 }




   
   
}
// tranfer end//

// sales list//
public function creationlist()
{

	$pagedata['record']=   $this->db->get('sale')->result_array(); 
 // print_r($pagedata); die;
	
	
	 $this->load->view('Admin/include/header');
    $this->load->view('admin/admin_dashboard',$pagedata);
    $this->load->view('Admin/include/footer');
   
   	
}


public function updatecreation($par1=''){
	$pagedata['id']=$par1;
	if($par1){
 $pagedata['updaterecord']= $this->db->get_where('sale',array('id' =>$par1))->row_array();
	}
	

 $this->load->view('Admin/include/header');
    $this->load->view('admin/admin_dashboard',$pagedata);
    $this->load->view('Admin/include/footer');
}   
   

// sales add//

public function companycreation_management($par1='',$par2='',$par3=''){
   

 $data=array(
    
  'date'=>$this->input->post('date'),
  'reference_no'=>$this->input->post('reference_no')
	
	);
  $this->load->view('Admin/include/header');
    $this->load->view('admin/admin_dashboard');
    $this->load->view('Admin/include/footer');
 if($par1=='create'){
            

	 		 $this->db->insert('sale' ,$data);
	 		//$this->load->view('addproduct');
	 		//$this->load->view('Product/addproduct');
	 	}
	 		//echo $result;die;
	 		//if($result){
	 			//$this->session->set_flashdata('success','record added successfully');
	 		//}else{
	 			//$this->session->set_flashdata('fail','unable to add please check');
	 		//}
	 		
	 		//redirect('product/productlist');
 //redirect


   if($par1=='update'){
	
	
	$id  =$this->input->post('id');
	$this->db->where( 'id' ,$id);
	$result=$this->db->update('sale',$data);

	if ($result) {
		# code...
	$this->session->set_flashdata('success','record update successfully');
    }
else{

      $this->session->set_flashdata('failure','record not updated');
	
  }
  redirect('product/creationlist');

}
	//update user recoord

 

 //redirect
//
	//delete
	 if ($par1=='delete') {
		 
		 
		
	 	$id=$par2;
	 	$this->db->where('id' ,$id);
	    $user=$this->db->delete('sale');

	 	# code...
	  	 if($user){
	  	 	$this->session->set_flashdata('success','record deleted successfully');
	  	 	
	  	 }
	  	else
	  	{ 
	  	 $this->session->set_flashdata('failure','record not found in database');
	  
	  	}
	redirect(base_url().'product/creationlist');
	  
	//
 }




   
   
}

// sales list//

//userlist//


 
 

   
   

// add  user//





//add user list//

//bill list//


 

   
   

/// bill addd//


// end bill//
//customer list//





   
   
// add customer//



//  add end list//
//  supplly list//
public function supplierlist()
{

	$pagedata['record']=   $this->db->get('add_product')->result_array(); 
 // print_r($pagedata); die;
	
	 $this->load->view('Admin/include/header');
    $this->load->view('admin/supplylist',$pagedata);
    $this->load->view('Admin/include/footer');
   
   	
}
  
  public function updatesupplier($par1=''){

  	$pagedata['id']=$par1;
  	if($par1){
$pagedata['updaterecord'] = $this->db->get_where('add_product',array('id'=>$par1))->row_array();

	}
 $this->load->view('Admin/include/header');
    $this->load->view('admin/addsupply',$pagedata);
    $this->load->view('Admin/include/footer');
   
  }

   
   


//  add supply//
public function supplier_management($par1='',$par2='',$par3=''){
   

 $data=array(
    
	'supplier_name'=>$this->input->post('supplier_name'),
	'gstid'=>$this->input->post('gstid'),
	'vatno'=>$this->input->post('vatno'),
	'panno'=>$this->input->post('panno'),
         'tan'=>  $this->input->post('tan'),
          'cstregno'=>  $this->input->post('cstregno'),
          'exciseregno'=>  $this->input->post('exciseregno'),
           'lbtregno'=>  $this->input->post('lbtregno'),
            'servicetaxno'=>  $this->input->post('servicetaxno'),
             '	gstregtype'=>  $this->input->post('gstregtype'),
              'company_name'=>  $this->input->post('company_name'),
              '	address'=>  $this->input->post('address'),
              'country'=>  $this->input->post('country'),
              '	state'=>  $this->input->post('state'),
              '	state_code'=>  $this->input->post('state_code'),
              '	city'=>  $this->input->post('city'),
               'postal_code'=>  $this->input->post('postal_code'),
                'mobile'=>  $this->input->post('mobile'),
                'email'=>  $this->input->post('email')
	);
  $this->load->view('Admin/include/header');
    $this->load->view('admin/addsupply');
    $this->load->view('Admin/include/footer');
   
 if($par1=='create'){
            

	 		 $this->db->insert('add_product' ,$data);
	 		//$this->load->view('addproduct');
	 		//$this->load->view('Product/addproduct');
	 	}
	 		//echo $result;die;
	 		//if($result){
	 			//$this->session->set_flashdata('success','record added successfully');
	 		//}else{
	 			//$this->session->set_flashdata('fail','unable to add please check');
	 		//}
	 		
	 		//redirect('product/productlist');
 //redirect


   if($par1=='update'){
	
	
	$id  =$this->input->post('id');
	$this->db->where( 'id' ,$id);
	$result=$this->db->update('add_product',$data);

	if ($result) {
		# code...
	$this->session->set_flashdata('success','record update successfully');
    }
else{

      $this->session->set_flashdata('failure','record not updated');
	
  }
  redirect('product/supplierlist');

}
	//update user recoord

 

 //redirect
//
	//delete
	 if ($par1=='delete') {
		 
		 
		
	 	$id=$par2;
	 	$this->db->where('id' ,$id);
	    $user=$this->db->delete('supply');

	 	# code...
	  	 if($user){
	  	 	$this->session->set_flashdata('success','record deleted successfully');
	  	 	
	  	 }
	  	else
	  	{ 
	  	 $this->session->set_flashdata('failure','record not found in database');
	  
	  	}
	redirect(base_url().'product/supplierlist');
	  
	//
 }




   
   
}

// lasst supply list//
//purchase list//


	/* 
	$par1 = create, update, delete
	$par2 = id


	*/

	




 
//last purchase//

//purchase_list//

	/* 
	$par1 = create, update, delete
	$par2 = id
	*/




 
// purchase return//


//category list//

public function Categorylist($par1=''){
	$pages['record']=   $this->db->get('add_category')->result_array(); 
  //print_r($pagedata); die;
      $this->load->view('Admin/include/header');
    $this->load->view('admin/listcategory',$pages);
    $this->load->view('Admin/include/footer');
   
   	
}

public function updatecategory($par1=''){
$page['id']=$par1;
if($par1){
$page['updaterecord'] = $this->db->get_where('add_category',array('id'=>$par1))->row_array();
//print_r($page); die;
	}

      $this->load->view('Admin/include/header');
    $this->load->view('admin/addcategory',$page);
    $this->load->view('Admin/include/footer');
}
	/* 
	$par1 = create, update, delete
	$par2 = id
	*/


// category add//

 public function mastercategory_management($par1='',$par2='',$par3=''){
   

 $data=array(
     
	'category_name'=>$this->input->post('category_name'),
	
	);
 //print_r($data); die;
   $this->load->view('Admin/include/header');
    $this->load->view('admin/addcategory');
    $this->load->view('Admin/include/footer');


 if($par1=='create'){
            

	 		 $this->db->insert('add_category' ,$data);	
	 	}
	 		// if($result){
	 		// 	$this->session->set_flashdata('success','record added successfully');
	 		// }else{
	 		// 	$this->session->set_flashdata('fail','unable to add please check');
	 		// }
	 		
	 		//redirect('product/productlist');
 //redirect

   if($par1=='update'){
	
	
	$id  =$this->input->post('id');
	$this->db->where( 'id' ,$id);
	$this->db->update('add_category',$data);

// 	if ($result) {
// 		# code...
// 	$this->session->set_flashdata('success','record update successfully');
//     }
// else{

//       $this->session->set_flashdata('failure','record not updated');
	
//   }
  redirect('product/Categorylist');

}
	//update user recoord

 

 //redirect
//
	//delete
	 if ($par1=='delete') {
		 
		 
		
	 	$id=$par2;
	 	$this->db->where('id' ,$id);
	    $this->db->delete('add_category');

	 	# code...
	  	//  if($result){
	  	//  	$this->session->set_flashdata('success','record deleted successfully');
	  	 	
	  	//  }
	  	// else
	  	// { 
	  	//  $this->session->set_flashdata('failure','record not found in database');
	  
	  	// }
	redirect(base_url().'product/Categorylist');
	  
	//
 }




   
   
}

// end category //

// branch list//


   
   

//purchase list//

//subcatlist//
public function Subcatlist(){	


$pagedata['record'] =$this->db->get('add_subcategory')->result_array(); 

 //print_r($pagedata); die;
  $this->load->view('Admin/include/header');
  $this->load->view('admin/listsubcategory',$pagedata);
  $this->load->view('Admin/include/footer');
   
   	
}

	/* 
	$par1 = create, update, delete
	$par2 = id
	*/
public function updatesubcat($par1=''){
$pagedata['id']=$par1;
if($par1){
$pagedata['updaterecord'] = $this->db->get_where('add_subcategory',array('id'=>$par1))->row_array();

	}


  $this->load->view('Admin/include/header');
    $this->load->view('admin/subcategoryadd',$pagedata);
    $this->load->view('Admin/include/footer');

}



 public function mastersubcateg_management($par1='',$par2='',$par3=''){
   

 $data=array(
 	     'category'=>$this->input->post('category'),
    	'subcategory_name'=>$this->input->post('subcategory_name')
	);
 //print_r($data); die;
 
   $this->load->view('Admin/include/header');
    $this->load->view('admin/subcategoryadd');
    $this->load->view('Admin/include/footer');



 if($par1=='create')
 {
            

	 		 $this->db->insert('add_subcategory' ,$data);
	 		
	 	}
	 		//echo $result;die;
	 		//if($user){
	 		//	$this->session->set_flashdata('success','record added successfully');
	 		//}else{
	 		//	$this->session->set_flashdata('fail','unable to add please check');
	 		//}
	 		
	 		//redirect('product/productlist');
 //redirect


   if($par1=='update'){
	
	
	$id  =$this->input->post('id');
	$this->db->where( 'id' ,$id);
	$result=$this->db->update('add_subcategory',$data);

	if ($result) {
		# code...
	$this->session->set_flashdata('success','record update successfully');
    }
else{

      $this->session->set_flashdata('failure','record not updated');
	
  }
  redirect('product/Subcatlist');

}
	//update user recoord

 

 //redirect
//
	//delete
	 if ($par1=='delete') {
		 
		 
		
	 	$id=$par2;
	 	$this->db->where('id' ,$id);
	    $user=$this->db->delete('add_subcategory');

	 	# code...
	  	 if($user){
	  	 	$this->session->set_flashdata('success','record deleted successfully');
	  	 	
	  	 }
	  	else
	  	{ 
	  	 $this->session->set_flashdata('failure','record not found in database');
	  
	  	}
	redirect(base_url().'product/Subcatlist');
	  
	//
 }




   
   
}

//subcat end//
//brand list//

}
	 
?>