<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	
	 public function __construct() {
        parent::__construct();
	}

	public function dashboard()
	{

		$this->load->view('Admin/include/header');
    $this->load->view('admin/admin_dashboard');
    $this->load->view('Admin/include/footer');
    
  }

    

	public function loginview()
	{
//$this->load->view('Admin/include/header');
$this->load->view('Admin/adminlogin');
 //$this->load->view('Admin/include/footer');
	}
	 
public function signup_management($par1='',$par2='',$par3=''){
   

 $data=array(
    
       'name'=>$this->input->post('name'),
      'email'=>$this->input->post('email'),
      'password'=>$this->input->post('password'),
       'mobilenumber'=>$this->input->post('mobilenumber')
         
          
  );

  $this->load->view('Admin/include/header');
    $this->load->view('Admin/usersingup');
    $this->load->view('Admin/include/footer');


 if($par1=='create'){
            

       $this->db->insert('signup' ,$data);
      
    }


  }
      //echo $result;die;
      //if($result){
        //$this->session->set_flashdata('success','record added successfully');
      //}else{
        //$this->session->set_flashdata('fail','unable to add please check');
      //}
      
      //redirect('product/productlist');
 //redirect




public function signin() {
        $mailid = $this->input->post('email');
        $paswd = $this->input->post('password');
        
      $result = $this->db->get_where('signup', array('email' =>$mailid, 'password' => $paswd));
    $data=$result->row_array();
   
    
    
    //echo '<pre>'; print_r($data); die; 
      $this->session->set_userdata('user',$data);
       $user = $this->session->userdata('user');
         // $num=$result->num_rows();
 //echo 'hii'; die;
        if(count($data)>0){
        	//echo 'hii'; die;
             $this->session->set_flashdata('success_message', 'Signin successfully');
//redirect('Admin/loginview'); die;
             redirect('Admin/dashboard');
        }
        else{
            $this->session->set_flashdata('error_message', 'Invalid Email Or Password');
            redirect('Admin/loginview');
            }
    }
     public function logout(){
        $newdata = array(
                'email'  =>'',
                'password' => '',
               );
              
        $this->session->unset_userdata($newdata);
        $this->session->sess_destroy();
      redirect('Admin/loginview');
      
     }
    
    public function profile(){
        
//databsen se data session id  ke through
$session = $this->session->userdata('user');

   $id = $session['user_id'];
   
   $data['userrecord'] = $this->db->get_where('signup',array('user_id'=> $id))->row_array();
   
//print_r($data); die; 

    $this->load->view('Admin/include/header');
    $this->load->view('Admin/profile',$data);
    $this->load->view('Admin/include/footer');
     
    }
        
    /* 
    $par1 = create, update, delete
    $par2 = id
    */




 public function usermanagement(){
   
   $formArray['name']=$this->input->post('name');
    $formArray['email']=$this->input->post('email');
    $formArray['password']=$this->input->post('password');
    
    $formArray['mobilenumber']=$this->input->post('mobilenumber');
    
   
//print_r($formArray['hobbies']);  die;

    $session = $this->session->userdata('user');
   $hidden_id =$this->input->post('hidden_id');
   $this->db->where( 'user_id' ,$hidden_id);
    $result=$this->db->update('crud',$formArray);
    ///echo $this->db->last_query();
   //print_r($result); die;
    if ($result) {
        # code...
    $this->session->set_flashdata('success','record update successfully');
    redirect('admin/Dashboard');
    }
else{

      $this->session->set_flashdata('failure','record not updated');
     redirect('admin/profile');
  }
  


    //
   
 } 
 }  
?>